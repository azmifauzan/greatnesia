		</div> <!-- /row -->
		
	</div> <!-- /container -->
	
</div> <!-- /content -->

<div id="footer">
	
	<div class="container">				
		<hr>
		<p>&copy; <?php echo date('Y') ?> <a href="http://www.gavne.com">Gavne Labs</a>.</p>
	</div> <!-- /container -->
	
</div> <!-- /footer -->


    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php echo base_url(); ?>js/jquery-1.7.2.min.js"></script>
<script src="<?php echo base_url(); ?>js/excanvas.min.js"></script>

<script src="<?php echo base_url(); ?>js/bootstrap.js"></script>

  </body>
</html>
